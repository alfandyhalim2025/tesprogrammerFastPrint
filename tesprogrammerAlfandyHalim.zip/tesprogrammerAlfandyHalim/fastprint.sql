-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2025 at 07:26 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fastprint`
--
CREATE DATABASE IF NOT EXISTS `fastprint` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `fastprint`;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `id_kategori` char(4) NOT NULL,
  `nama_kategori` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `kategori`
--

TRUNCATE TABLE `kategori`;
--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
('K001', 'Kertas'),
('K002', 'Spidol'),
('K003', 'Pensil'),
('K004', 'Pulpen'),
('K005', 'Krayon');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `id_produk` char(4) NOT NULL,
  `nama_produk` varchar(256) NOT NULL,
  `harga` int(12) NOT NULL,
  `kategori_id` char(4) NOT NULL,
  `status_id` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `produk`
--

TRUNCATE TABLE `produk`;
--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga`, `kategori_id`, `status_id`) VALUES
('P001', 'Pensil Kayu 2B untuk Anak dengan Karakter', 11000, 'K003', 'S001'),
('P002', 'Pensil Joyko', 1050, 'K003', 'S002'),
('P003', 'Pensil Joyko 2B Hitam', 1400, 'K003', 'S001'),
('P004', 'Pensil Handy 2B', 1200, 'K003', 'S001'),
('P005', 'Pensil Warna Faber-Castell', 14000, 'K003', 'S001'),
('P006', 'Pensil Staedtler 2B 1 Lusin', 14400, 'K003', 'S001'),
('P007', 'Kertas HVS A4 PAPERONE 75GR', 40000, 'K001', 'S001'),
('P008', 'Kertas HVS Paper One B5 70 Gr', 45600, 'K001', 'S001'),
('P009', 'KERTAS HVS SIDU A4 / f4 75GSM', 52990, 'K001', 'S001'),
('P010', 'Kertas HVS A4 75gr / 75 gram Copy Papper / Copypapper - 1 Rim (500 Lembar)', 44890, 'K001', 'S001'),
('P011', 'Pensil Station 2B', 1200, 'K003', 'S001'),
('P012', 'Pensil Greebel 2B', 5500, 'K003', 'S002'),
('P013', 'Crayon Titi Isi 55 Warna', 165000, 'K005', 'S001'),
('P014', 'Crayon Joyko / Titi isi 55 Warna', 180000, 'K005', 'S001');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id_status` char(4) NOT NULL,
  `nama_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `status`
--

TRUNCATE TABLE `status`;
--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `nama_status`) VALUES
('S001', 'Bisa Dijual'),
('S002', 'Habis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
