<?php

class Produk_model extends CI_Model
{
   // public function getAllProdukWithStatus($status_id = null, $limit, $start)
   // {
   //    $this->db->select('p.id_produk, p.nama_produk, p.harga, s.nama_status, k.nama_kategori');
   //    $this->db->from('produk as p');
   //    $this->db->join('status as s', 'p.status_id = s.id_status', 'left');
   //    $this->db->join("kategori as k", "p.kategori_id = k.id_kategori", 'left');

   //    if ($status_id) {
   //       $this->db->where('p.status_id', $status_id);
   //    }

   //    $this->db->limit($limit, $start);

   //    return $this->db->get()->result();
   // }

   public function getAllProdukActive($limit, $start)
   {
      $this->db->select('p.id_produk, p.nama_produk, p.harga, s.nama_status, k.nama_kategori');
      $this->db->from('produk as p');
      $this->db->join('status as s', 'p.status_id = s.id_status', 'left');
      $this->db->join("kategori as k", "p.kategori_id = k.id_kategori", 'left');
      $this->db->where('s.nama_status', "Bisa Dijual");

      $this->db->limit($limit, $start);

      return $this->db->get()->result();
   }

   public function count($status_id = null)
   {
      if ($status_id) {
         $this->db->where('status_id', $status_id);
      }
      return $this->db->count_all_results('produk');
   }

   public function generate_code()
   {
      $this->db->select('id_produk');
      $this->db->from('produk');
      $this->db->order_by('id_produk', 'DESC');
      $this->db->limit(1);
      $query = $this->db->get();

      if ($query->num_rows() > 0) {
         $row = $query->row();
         $last_code = $row->id_produk;
         $num = (int) substr($last_code, 1);
         $num++;
         $new_code = 'P' . str_pad($num, 3, '0', STR_PAD_LEFT);
      } else {
         $new_code = 'P001';
      }

      return $new_code;
   }

   public function insert($data)
   {
      return $this->db->insert('produk', $data);
   }

   public function get_produk_by_id($id)
   {
      $this->db->select('p.id_produk, p.nama_produk, p.harga, s.nama_status, k.nama_kategori');
      $this->db->from('produk as p');
      $this->db->join('status as s', 'p.status_id = s.id_status', 'left');
      $this->db->join("kategori as k", "p.kategori_id = k.id_kategori", 'left');
      $this->db->where('p.id_produk', $id);
      return $this->db->get()->row();
   }

   public function update($id, $data)
   {
      $this->db->where('id_produk', $id);
      return $this->db->update('produk', $data);
   }

   public function delete($id)
   {
      $this->db->where('id_produk', $id);
      return $this->db->delete('produk');
   }
}



?>