<?php

class Status_model extends CI_Model
{
   public function getAllStatus()
   {
      return $this->db->get("status")->result();
   }

   public function generate_code()
   {
      $this->db->select('id_status');
      $this->db->from('status');
      $this->db->order_by('id_status', 'DESC');
      $this->db->limit(1);
      $query = $this->db->get();

      if ($query->num_rows() > 0) {
         $row = $query->row();
         $last_code = $row->id_status;
         $num = (int) substr($last_code, 1);
         $num++;
         $new_code = 'S' . str_pad($num, 3, '0', STR_PAD_LEFT);
      } else {
         $new_code = 'S001';
      }

      return $new_code;
   }

   public function get_status_by_id($id)
   {
      return $this->db->get_where('status', ['id_status' => $id])->row();
   }

   public function insert($data)
   {
      return $this->db->insert('status', $data);
   }

   public function update($id, $data)
   {
      $this->db->where('id_status', $id);
      return $this->db->update('status', $data);
   }

   public function delete($id)
   {
      $this->db->where('id_status', $id);
      return $this->db->delete('status');
   }

}


?>