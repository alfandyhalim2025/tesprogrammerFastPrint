<?php

class Kategori_model extends CI_Model
{
   public function getAllKategori()
   {
      return $this->db->get("kategori")->result();
   }

   public function generate_code()
   {
      $this->db->select('id_kategori');
      $this->db->from('kategori');
      $this->db->order_by('id_kategori', 'DESC');
      $this->db->limit(1);
      $query = $this->db->get();

      if ($query->num_rows() > 0) {
         $row = $query->row();
         $last_code = $row->id_kategori;
         $num = (int) substr($last_code, 1);
         $num++;
         $new_code = 'K' . str_pad($num, 3, '0', STR_PAD_LEFT);
      } else {
         $new_code = 'K001';
      }

      return $new_code;
   }

   public function insert($data)
   {
      return $this->db->insert('kategori', $data);
   }

   public function get_kategori_by_id($id)
   {
      return $this->db->get_where('kategori', ['id_kategori' => $id])->row();
   }

   public function update($id, $data)
   {
      $this->db->where('id_kategori', $id);
      return $this->db->update('kategori', $data);
   }

   public function delete($id)
   {
      $this->db->where('id_kategori', $id);
      return $this->db->delete('kategori');
   }
}


?>