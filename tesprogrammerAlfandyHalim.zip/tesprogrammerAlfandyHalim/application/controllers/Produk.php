<?php

class Produk extends CI_Controller
{

   public function __construct()
   {
      parent::__construct();
      $this->load->model("Produk_model");
      $this->load->model("Kategori_model");
      $this->load->model("Status_model");
   }

   private function pagination_config($base_url, $total_rows, $limit)
   {
      $config['base_url'] = $base_url;
      $config['total_rows'] = $total_rows;
      $config['per_page'] = $limit;
      $config['uri_segment'] = 3;

      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['num_tag_open'] = '<li>';
      $config['num_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="active"><a href="#">';
      $config['cur_tag_close'] = '</a></li>';
      $config['prev_tag_open'] = '<li>';
      $config['prev_tag_close'] = '</li>';
      $config['next_tag_open'] = '<li>';
      $config['next_tag_close'] = '</li>';
      $config['first_tag_open'] = '<li>';
      $config['first_tag_close'] = '</li>';
      $config['last_tag_open'] = '<li>';
      $config['last_tag_close'] = '</li>';
      return $config;
   }

   public function index()
   {
      $status_id = $this->input->get('status_id');
      $limit = 9;
      $total_rows = $this->Produk_model->count($status_id);
      $base_url = site_url("produk/index");

      $config = $this->pagination_config($base_url, $total_rows, $limit);

      $this->pagination->initialize($config);

      $offset = $this->uri->segment(3, 0);
      // $data["produk"] = $this->Produk_model->getAllProdukWithStatus($status_id, $limit, $offset);
      $data["produk"] = $this->Produk_model->getAllProdukActive($limit, $offset);
      $data["status"] = $this->Status_model->getAllStatus();
      $data["active_page"] = "produk";
      $this->load->view("header/navbar", $data);
      $data['pagination_links'] = $this->pagination->create_links();
      $this->load->view("home/produk", $data);

   }

   public function load_data_with_id($id)
   {
      $data['produk'] = $this->Produk_model->get_produk_by_id($id);
      $data["status"] = $this->Status_model->getAllStatus();
      $data["kategori"] = $this->Kategori_model->getAllKategori();
      return $data;
   }

   public function load_data()
   {
      $data["status"] = $this->Status_model->getAllStatus();
      $data["kategori"] = $this->Kategori_model->getAllKategori();
      return $data;
   }

   public function view_insert()
   {
      $data = $this->load_data();
      $this->load->view("input/input_produk", $data);
   }

   public function insert()
   {
      $data = $this->load_data();
      $this->form_validation->set_rules(
         'namaproduk',
         'nama produk',
         'required',
         [
            'required' => 'Kolom {field} harus diisi'
         ]
      );
      $this->form_validation->set_rules(
         'harga',
         'harga',
         'required|numeric',
         [
            'required' => 'Kolom {field} harus diisi',
            'numeric' => 'Kolom {field} harus berupa angka'
         ]
      );

      $id_produk = $this->Produk_model->generate_code();

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_produk", $data);
      } else {
         $data = array(
            "id_produk" => $id_produk,
            "nama_produk" => $this->input->post("namaproduk"),
            "harga" => $this->input->post("harga"),
            "kategori_id" => $this->input->post("id_kategori"),
            "status_id" => $this->input->post("id_status")
         );

         $this->Produk_model->insert($data);
         $this->session->set_flashdata('success', 'Produk berhasil ditambahkan dengan kode ' . $id_produk);
         redirect("produk/index");
      }
   }

   public function view_update($id)
   {
      $data = $this->load_data_with_id($id);
      $this->load->view("input/input_produk", $data);
   }

   public function update($id)
   {
      $data = $this->load_data_with_id($id);
      $this->form_validation->set_rules(
         'namaproduk',
         'nama produk',
         'required',
         ['required' => 'kolom {field} harus diisi']
      );

      $this->form_validation->set_rules(
         'harga',
         'harga',
         'required|numeric',
         [
            'required' => 'Kolom {field} harus diisi',
            'numeric' => 'Kolom {field} harus berupa angka'
         ]
      );

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_produk", $data);
      } else {
         $data = [
            'nama_produk' => $this->input->post('namaproduk'),
            "harga" => $this->input->post("harga"),
            "kategori_id" => $this->input->post("id_kategori"),
            "status_id" => $this->input->post("id_status")
         ];

         $this->Produk_model->update($id, $data);
         $this->session->set_flashdata("success", "Produk berhasil diperbarui!");

         redirect("produk/index");
      }

   }

   public function delete($id)
   {
      $this->Produk_model->delete($id);
      $this->session->set_flashdata("success", "Produk berhasil dihapus");
      redirect("produk/index");
   }

}

