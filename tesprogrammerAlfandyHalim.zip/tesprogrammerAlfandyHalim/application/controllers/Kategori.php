<?php

class Kategori extends CI_Controller
{

   public function __construct()
   {
      parent::__construct();
      $this->load->model("Kategori_model");
   }

   public function index()
   {
      $data["kategori"] = $this->Kategori_model->getAllKategori();
      $data["active_page"] = "kategori";
      $this->load->view("header/navbar", $data);
      $this->load->view("home/kategori", $data);
   }

   public function view_insert()
   {
      $this->load->view("input/input_kategori");
   }

   public function insert()
   {
      $this->form_validation->set_rules(
         'namakategori',
         'nama kategori',
         'required',
         ['required' => 'kolom {field} harus diisi']
      );

      $id_kategori = $this->Kategori_model->generate_code();

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_kategori");
      } else {
         $data = array(
            "id_kategori" => $id_kategori,
            "nama_kategori" => $this->input->post("namakategori"),
         );

         $this->Kategori_model->insert($data);
         $this->session->set_flashdata('success', 'Kategori berhasil ditambahkan dengan kode ' . $id_kategori);
         redirect("kategori/index");
      }

   }

   public function view_update($id)
   {
      $data['kategori'] = $this->Kategori_model->get_kategori_by_id($id);
      $this->load->view("input/input_kategori", $data);
   }

   public function update($id)
   {
      $data['kategori'] = $this->Kategori_model->get_kategori_by_id($id);
      $this->form_validation->set_rules(
         'namakategori',
         'nama kategori',
         'required',
         ['required' => 'kolom {field} harus diisi']
      );

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_kategori", $data);
      } else {
         $data = [
            'nama_kategori' => $this->input->post('namakategori')
         ];

         $this->Kategori_model->update($id, $data);
         $this->session->set_flashdata("success", "Kategori berhasil diperbarui!");

         redirect("kategori/index");
      }

   }

   public function delete($id)
   {
      $this->Kategori_model->delete($id);
      $this->session->set_flashdata("success", "Kategori berhasil dihapus");
      redirect("kategori/index");
   }

}

?>