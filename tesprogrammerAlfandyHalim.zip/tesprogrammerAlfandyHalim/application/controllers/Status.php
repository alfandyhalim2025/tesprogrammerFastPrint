<?php

class Status extends CI_Controller
{

   public function __construct()
   {
      parent::__construct();
      $this->load->model("Status_model");
   }

   public function index()
   {
      $data["status"] = $this->Status_model->getAllStatus();
      $data["active_page"] = "status";
      $this->load->view("header/navbar", $data);
      $this->load->view("home/status", $data);
   }

   public function view_insert()
   {
      $this->load->view("input/input_status");
   }

   public function insert()
   {
      $this->form_validation->set_rules(
         'namastatus',
         'nama status',
         'required',
         ['required' => 'kolom {field} harus diisi']
      );

      $id_status = $this->Status_model->generate_code();

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_status");
      } else {
         $data = array(
            "id_status" => $id_status,
            "nama_status" => $this->input->post("namastatus"),
         );

         $this->Status_model->insert($data);
         $this->session->set_flashdata('success', 'Status berhasil ditambahkan dengan kode ' . $id_status);
         redirect("status/index");
      }
   }

   public function view_update($id)
   {
      $data['status'] = $this->Status_model->get_status_by_id($id);
      $this->load->view("input/input_status", $data);
   }

   public function update($id)
   {
      $data['status'] = $this->Status_model->get_status_by_id($id);
      $this->form_validation->set_rules(
         'namastatus',
         'nama status',
         'required',
         ['required' => 'kolom {field} harus diisi']
      );

      if ($this->form_validation->run() === FALSE) {
         $this->load->view("input/input_status", $data);
      } else {
         $data = [
            'nama_status' => $this->input->post('namastatus')
         ];

         $this->Status_model->update($id, $data);
         $this->session->set_flashdata("success", "Status berhasil diperbarui!");

         redirect("status/index");
      }

   }

   public function delete($id)
   {
      $this->Status_model->delete($id);
      $this->session->set_flashdata("success", "Status berhasil dihapus");
      redirect("status/index");
   }

}


?>