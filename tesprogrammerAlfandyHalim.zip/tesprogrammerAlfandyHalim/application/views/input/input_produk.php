<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Insert Produk</title>
</head>

<body>

   <div class="container">
      <div style="margin-bottom: 10px;">
         <a href="<?php echo base_url("") ?>">
            <button>Kembali</button>
         </a>
      </div>

      <?php echo form_open(isset($produk) ? 'produk/update/' . $produk->id_produk : 'produk/insert') ?>

      <div class="error">
         <?= form_error('namaproduk'); ?>
         <?= form_error('harga'); ?>
      </div>

      <?php if (!empty($produk)): ?>
         <div class="readonly">
            <div class="input-section">
               <label for="namaproduk"><?= $produk->nama_produk ?></label><br><br>
               <label for="idproduk">Id Produk:</label><br>
               <input type="text" id="idproduk" name="idproduk" value="<?= $produk->id_produk ?>" disabled>
               <br>
               <label for="harga">Harga:</label><br>
               <input type="text" id="harga" name="harga" value="<?= $produk->harga ?>" disabled>
               <br>
               <label for="status">Status Produk:</label><br>
               <input type="text" id="status" name="status" value="<?= $produk->nama_status ?>" disabled>
               <br>
               <label for="kategori">Kategori:</label><br>
               <input type="text" id="kategori" name="kategori" value="<?= $produk->nama_kategori ?>" disabled>
               <br>

            </div>
         </div>

      <?php endif ?>

      <div class="input-box">

         <div class="input-section">
            <label for="namaproduk">Nama Produk:</label><br>
            <input type="text" id="namaproduk" name="namaproduk" value="<?php echo set_value('namaproduk'); ?>">
            <br><br>

            <label for="harga">Harga Produk (IDR):</label><br>
            <input type="text" id="harga" name="harga" value="<?php echo set_value('harga'); ?>">
            <br><br>

            <label for="status">Status:</label><br>
            <select name="id_status">
               <?php foreach ($status as $stat): ?>
                  <option value="<?php echo $stat->id_status; ?>">
                     <?php echo $stat->nama_status; ?>
                  </option>
               <?php endforeach; ?>
            </select>
            <br><br>

            <label for="kategori">Kategori:</label><br>
            <select name="id_kategori">
               <?php foreach ($kategori as $ktg): ?>
                  <option value="<?php echo $ktg->id_kategori; ?>">
                     <?php echo $ktg->nama_kategori; ?>
                  </option>
               <?php endforeach; ?>
            </select>
            <br><br>



            <input style="margin-top: 10px;" type="submit" value="Submit">
         </div>
         <? echo form_close(); ?>

      </div>
</body>

</html>