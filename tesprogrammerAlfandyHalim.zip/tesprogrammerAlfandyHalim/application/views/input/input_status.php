<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Insert Status</title>
</head>

<body>
   <div class="container">
      <div style="margin-bottom: 10px;">
         <a href="<?php echo base_url("status") ?>">
            <button>Kembali</button>
         </a>
      </div>


      <?php echo form_open(isset($status) ? 'status/update/' . $status->id_status : 'status/insert') ?>

      <div class="error">
         <?= form_error('namastatus'); ?>
      </div>

      <?php if (!empty($status)): ?>
         <div class="readonly">
            <div class="input-section">
               <label for="idstatus">Id Status:</label><br>
               <input type="text" id="idstatus" name="idstatus" value="<?= $status->id_status ?>" disabled>
               <br>
               <label for="namastatus">Nama Status:</label><br>
               <input type="text" id="namastatus" name="namastatus" value="<?= $status->nama_status ?>" disabled>
            </div>
         </div>

      <?php endif ?>

      <div class="input-box">

         <div class="input-section">
            <label for="namastatus">Nama Status:</label><br>
            <input type="text" id="namastatus" name="namastatus" value="<?php echo set_value('namastatus'); ?>">
            <br>

            <input style="margin-top: 10px;" type="submit" value="Submit">
         </div>
         <? echo form_close(); ?>

      </div>
   </div>
</body>

</html>