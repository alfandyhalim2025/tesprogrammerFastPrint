<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Insert Kategori</title>
</head>

<body>
   <div class="container">
      <div style="margin-bottom: 10px;">
         <a href="<?php echo base_url("kategori") ?>">
            <button>Kembali</button>
         </a>
      </div>


      <?php echo form_open(isset($kategori) ? 'kategori/update/' . $kategori->id_kategori : 'kategori/insert') ?>

      <div class="error">
         <?= form_error('namakategori'); ?>
      </div>

      <?php if (!empty($kategori)): ?>
         <div class="readonly">
            <div class="input-section">
               <label for="idkategori">Id Kategori:</label><br>
               <input type="text" id="idkategori" name="idkategori" value="<?= $kategori->id_kategori ?>" disabled>
               <br>
               <label for="namakategori">Nama Kategori:</label><br>
               <input type="text" id="namakategori" name="namakategori" value="<?= $kategori->nama_kategori ?>" disabled>
            </div>
         </div>

      <?php endif ?>

      <div class="input-box">

         <div class="input-section">
            <label for="namakategori">Nama Kategori:</label><br>
            <input type="text" id="namakategori" name="namakategori" value="<?php echo set_value('namakategori'); ?>">
            <br>

            <input style="margin-top: 10px;" type="submit" value="Submit">
         </div>
         <? echo form_close(); ?>

      </div>
   </div>


</body>

</html>