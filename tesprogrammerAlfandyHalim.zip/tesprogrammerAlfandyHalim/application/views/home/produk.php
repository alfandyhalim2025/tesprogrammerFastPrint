<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Produk</title>
</head>

<body>
   <div class="container">

      <?php if ($this->session->flashdata('success')): ?>
         <div class="success">
            <?php echo $this->session->flashdata('success'); ?>
         </div>
      <?php endif; ?>

      <!-- <form method="GET" action="">
         <label for=" status" style="margin-bottom: 10px;">Filter berdasarkan Status:</label>
         <select name="status_id" onchange="this.form.submit()">
            <option value="">-- Semua Status --</option>
            <?php foreach ($status as $stat): ?>
               <option value="<?php echo $stat->id_status; ?>" <?php echo isset($_GET['status_id']) && $_GET['status_id'] == $stat->id_status ? 'selected' : ''; ?>>
                  <?php echo $stat->nama_status; ?>
               </option>
            <?php endforeach; ?>
         </select>
      </form> -->

      <?php if (!empty($produk)): ?>

         <table>
            <thead>
               <tr>
                  <th>ID Produk</th>
                  <th>Nama Produk</th>
                  <th>Harga (IDR)</th>
                  <th>Kategori</th>
                  <th>Status</th>
                  <th>Edit / Hapus</th>
               </tr>
            </thead>

            <tbody>
               <?php foreach ($produk as $pro): ?>
                  <tr>
                     <td><?= $pro->id_produk ?></td>
                     <td style="width: 40%"><?= character_limiter($pro->nama_produk, 50) ?></td>
                     <td style="text-align:right;"><?= number_format($pro->harga, 0, '.', ','); ?></td>
                     <td><?= $pro->nama_kategori ?></td>
                     <td><?= $pro->nama_status ?></td>
                     <td>
                        <a class="table-button blue" href="<?php echo site_url('produk/view_update/' . $pro->id_produk); ?>">
                           Edit
                        </a>
                        <a class="table-button red" href="<?= site_url("produk/delete/" . $pro->id_produk); ?>"
                           onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
                           Hapus
                        </a>

                     </td>
                  </tr>
               <?php endforeach ?>
            </tbody>
         </table>
         <div>
            <?php echo $pagination_links; ?>
         </div>

      <?php else: ?>
         <p>Tidak ada data yang tersedia</p>
      <?php endif ?>

      <a href="<?php echo site_url("produk/view_insert"); ?>"><button>Insert</button></a>

   </div>


</body>

</html>