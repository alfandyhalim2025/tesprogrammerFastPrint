<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Kategori</title>
</head>

<body>

   <div class="container">
      <?php if ($this->session->flashdata('success')): ?>
         <div class="success">
            <?php echo $this->session->flashdata('success'); ?>
         </div>
      <?php endif; ?>
      <?php if (!empty($kategori)): ?>

         <table>
            <thead>
               <tr>
                  <th>ID Kategori</th>
                  <th>Nama Kategori</th>
                  <th>Edit / Hapus</th>
               </tr>
            </thead>

            <tbody>
               <?php foreach ($kategori as $ktg): ?>
                  <tr>
                     <td><?= $ktg->id_kategori ?></td>
                     <td><?= $ktg->nama_kategori ?></td>
                     <td>
                        <a class="table-button blue"
                           href="<?php echo site_url('kategori/view_update/' . $ktg->id_kategori); ?>">
                           Edit
                        </a>
                        <a class="table-button red" href="<?= site_url("kategori/delete/" . $ktg->id_kategori); ?>"
                           onclick="return confirm('Apakah Anda yakin ingin menghapus kategori ini?');">
                           Hapus
                        </a>

                     </td>
                  </tr>
               <?php endforeach ?>
            </tbody>
         </table>

      <?php else: ?>
         <p>Tidak ada data yang tersedia</p>
      <?php endif ?>
      <a href="<?php echo site_url("kategori/view_insert"); ?>"><button>Insert</button></a>


   </div>


</body>

</html>