<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>">
   <title>Status</title>
</head>

<body>
   <div class="container">
      <?php if ($this->session->flashdata('success')): ?>
         <div class="success">
            <?php echo $this->session->flashdata('success'); ?>
         </div>
      <?php endif; ?>
      <?php if (!empty($status)): ?>

         <table>
            <thead>
               <tr>
                  <th>ID Status</th>
                  <th>Nama Status</th>
                  <th>Edit / Hapus</th>
               </tr>
            </thead>

            <tbody>
               <?php foreach ($status as $stat): ?>
                  <tr>
                     <td><?= $stat->id_status ?></td>
                     <td><?= $stat->nama_status ?></td>
                     <td>
                        <a class="table-button blue" href="<?php echo site_url('status/view_update/' . $stat->id_status); ?>">
                           Edit
                        </a>
                        <a class="table-button red" href="<?= site_url("status/delete/" . $stat->id_status); ?>"
                           onclick="return confirm('Apakah Anda yakin ingin menghapus status ini?');">
                           Hapus
                        </a>

                     </td>
                  </tr>
               <?php endforeach ?>
            </tbody>
         </table>

      <?php else: ?>
         <p>Tidak ada data yang tersedia</p>
      <?php endif ?>
      <a href="<?php echo site_url("status/view_insert"); ?>"><button>Insert</button></a>

   </div>
</body>

</html>