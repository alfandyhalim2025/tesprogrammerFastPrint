<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<style>
   .navbar {
      list-style-type: none;
      margin: 20px;
      overflow: hidden;
      background-color: #333;
   }

   .navbar li {
      float: left;
   }

   .navbar li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
   }

   .navbar li a:hover:not(.active) {
      background-color: #111;
   }

   .active {
      background-color: #04AA6D;
   }
</style>

<body>
   <ul class="navbar">
      <li><a class="<?php echo ($active_page == "produk" ? "active" : "") ?>" href="<?= site_url(""); ?>">Produk</a>
      </li>
      <li><a class="<?php echo ($active_page == "kategori" ? "active" : "") ?>"
            href="<?= site_url("kategori"); ?>">Kategori</a></li>
      <li><a class="<?php echo ($active_page == "status" ? "active" : "") ?>"
            href="<?= site_url("status"); ?>">Status</a></li>
   </ul>
</body>

</html>